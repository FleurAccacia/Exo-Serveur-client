import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.Scanner;

public class BasicClient {
     public static void main (String[] toto){
         try{
             Socket clientSocket = new Socket("localhost", 5000);


             OutputStream os = clientSocket.getOutputStream();
             PrintWriter pw = new PrintWriter(os,true);
             //pw.println("Vous avez envoye : " +requete);
             pw.println("Message envoyé 👌👌👌");


             //Permettre au client d'envoyer plusieurs requetes
             String requete= " ";
             while (!requete.equals("bye")){

                 System.out.println("Entrez votre requete : ");
                 Scanner sc = new Scanner(System.in);
                 requete = sc.nextLine();

                 //Capitalise les messages du clients
                 String capitaleMessage = requete.toUpperCase();
                 System.out.println("Message capitalisé : " +capitaleMessage);
             }
             //fermeture
             clientSocket.close();



         } catch (IOException ex) {
             ex.printStackTrace();
         }
     }
}
