import java.io.*;
        import java.net.ServerSocket;
import java.net.Socket;

public class OperationServer {
    public static void main(String[] args) {
        try {
            // Démarrage du serveur sur le port 5000
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Serveur en attente de connexions...");

            // Acceptation de la connexion client
            Socket clientSocket = serverSocket.accept();
            System.out.println("Client connecté.");

            // Création des flux pour lire/écrire avec le client
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

            String operation;
            while ((operation = in.readLine()) != null) {
                if (operation.equalsIgnoreCase("bye")) {
                    System.out.println("Client déconnecté.");
                    break;
                }

                System.out.println("Opération reçue : " + operation);

                // Calcul de l'opération
                String result = calculate(operation);
                System.out.println("Résultat calculé : " + result);

                // Envoi du résultat au client
                out.println(result);
            }

            // Fermeture des connexions
            clientSocket.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour calculer une opération simple
    private static String calculate(String operation) {
        try {
            String[] parts = operation.split(" ");
            if (parts.length != 3) {
                return "Format invalide. Utilisez : nombre1 opérateur nombre2";
            }

            double num1 = Double.parseDouble(parts[0]);
            String operator = parts[1];
            double num2 = Double.parseDouble(parts[2]);

            switch (operator) {
                case "+":
                    return String.valueOf(num1 + num2);
                case "-":
                    return String.valueOf(num1 - num2);
                case "*":
                    return String.valueOf(num1 * num2);
                case "/":
                    if (num2 == 0) return "Erreur : Division par zéro";
                    return String.valueOf(num1 / num2);
                default:
                    return "Opérateur invalide. Utilisez +, -, *, ou /";
            }
        } catch (NumberFormatException e) {
            return "Erreur : Entrez des nombres valides.";
        }
    }
}
