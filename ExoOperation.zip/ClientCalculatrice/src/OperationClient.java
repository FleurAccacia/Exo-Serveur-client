import java.io.*;
        import java.net.Socket;
import java.util.Scanner;

public class OperationClient {
    public static void main(String[] args) {
        try {
            // Connexion au serveur
            Socket clientSocket = new Socket("localhost", 5000);
            System.out.println("Connecté au serveur.");

            // Création des flux pour lire/écrire avec le serveur
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

            Scanner scanner = new Scanner(System.in);
            String operation;

            while (true) {
                System.out.println("Entrez une opération (ex : 5 + 3) ou 'bye' pour quitter : ");
                operation = scanner.nextLine();

                // Envoi de l'opération au serveur
                out.println(operation);

                if (operation.equalsIgnoreCase("bye")) {
                    System.out.println("Déconnexion...");
                    break;
                }

                // Lecture de la réponse du serveur
                String response = in.readLine();
                System.out.println("Résultat : " + response);
            }

            // Fermeture des connexions
            clientSocket.close();
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
